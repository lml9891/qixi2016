$(function () {
  $('#winCode').html(localStorage.WINCODE);
})
